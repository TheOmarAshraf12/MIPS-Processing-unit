import java.util.ArrayList;

public class InstructionMemory {
	 short[] instructions = new short[1024];
	
	
	 
	 




public static void main(String[]args) {
	
	
	
	
}

}